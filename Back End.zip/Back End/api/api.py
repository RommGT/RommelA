# api.py

import os
import numpy as np
import cv2
from deepface import DeepFace
from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
import tempfile
from django.conf import settings
import pandas as pd  # You can remove this import if not needed elsewhere
from datetime import datetime  # You can remove this import if not needed elsewhere
from .serializers import ApiSerializer, AttendanceRecordSerializer
from .models import Api, AttendanceRecord, EmbeddingRecord  # Import the new model
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import IsAdminUser
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.response import Response

# Crear una carpeta 'temp' en el mismo directorio del código
TEMP_DIR = os.path.join(os.path.dirname(__file__), 'temp')
os.makedirs(TEMP_DIR, exist_ok=True)

# Helper functions (keep decode_image)
def decode_image(image_file):
    # Read the image from the uploaded file
    image_data = image_file.read()
    image_np = np.frombuffer(image_data, dtype=np.uint8)
    image = cv2.imdecode(image_np, cv2.IMREAD_COLOR)
    return image

class ApiViewSet(viewsets.ModelViewSet):
    queryset = Api.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = ApiSerializer
  # Método register
  
    @action(detail=False, methods=['post'])
    def register(self,request):
        # Validar los datos enviados
        if 'email' not in request.POST:
            return JsonResponse({"error": "Falta email"}, status=400)

        if 'images' not in request.FILES:
            return JsonResponse({"error": "Falta imagen"}, status=400)

        user_email = request.POST['email']
        images = request.FILES.getlist('images')

        if not user_email or not images:
            return JsonResponse({"error": "No hay imagen ni email"}, status=400)

        # Generar embeddings para las imágenes cargadas
        embeddings = []
        for image_file in images:
            # Leer la imagen del archivo cargado
            image_data = image_file.read()
            image_np = np.frombuffer(image_data, dtype=np.uint8)
            image = cv2.imdecode(image_np, cv2.IMREAD_COLOR)

            # Preprocesamiento de la imagen (si es necesario)
            if image is None:
                return JsonResponse({"error": "Error al decodificar la imagen"}, status=400)

            # Cambiar el tamaño de la imagen si es muy grande
            height, width = image.shape[:2]
            if max(height, width) > 1080:
                scale_factor = 1080 / max(height, width)
                image = cv2.resize(image, (int(width * scale_factor), int(height * scale_factor)))

            # Generar el embedding con DeepFace
            try:
                result = DeepFace.represent(img_path=image, model_name="Facenet", enforce_detection=True)
                for face_data in result:
                    embeddings.append(face_data["embedding"])  # Extraer solo el embedding
            except Exception as e:
                return JsonResponse({"error": f"Error al procesar la imagen: {str(e)}"}, status=500)

            # Calcular el promedio de embeddings si hay varias imágenes
            if embeddings:
                averaged_embedding = np.mean(embeddings, axis=0).tolist()  # Promedio de embeddings
            else:
                return JsonResponse({"error": "No se pudieron generar embeddings"}, status=500)

            # Guardar o actualizar el embedding en la base de datos
            record, created = EmbeddingRecord.objects.update_or_create(
                email=user_email,
                defaults={
                    "embedding": averaged_embedding,
                }
            )

            return Response({"result": "ok"}, status=status.HTTP_200_OK)

    
      
    @action(detail=False, methods=['post'])
    def authenticate(self, request):
        # Validar los datos de la solicitud
        if 'image' not in request.FILES:
            return Response({"error": "No image file provided"}, status=status.HTTP_200_OK)

        if 'email' not in request.data:
            return Response({"error": "No email provided"}, status=status.HTTP_200_OK)

        if 'class' not in request.data:
            return Response({"error": "No class provided"}, status=status.HTTP_200_OK)

        image_file = request.FILES['image']
        user_email = request.data['email']
        class_name = request.data['class']

        if not image_file or not user_email or not class_name:
            return Response({"error": "No se envia imagen, correo o clase"}, status=status.HTTP_200_OK)

        try:
            # Decodificar la imagen del archivo
            image_data = image_file.read()
            image_np = np.frombuffer(image_data, dtype=np.uint8)
            img = cv2.imdecode(image_np, cv2.IMREAD_COLOR)

            if img is None:
                return Response({"error": "Imagen Invalida"}, status=status.HTTP_400_BAD_REQUEST)

            sanitized_email = user_email.replace("@", "_at_").replace(".", "_dot_")  # Sanitizar email
            temp_file_path = os.path.join(TEMP_DIR, f"{sanitized_email}_temp_image.jpg")
            cv2.imwrite(temp_file_path, img)

            # Validar si la imagen es real usando anti-spoofing
            try:
                face_objs = DeepFace.extract_faces(
                    img_path=temp_file_path,
                    detector_backend='opencv',
                    anti_spoofing=True
                )

                all_faces_real = all(face_obj.get("is_real", False) for face_obj in face_objs)
                if not all_faces_real:
                       # Eliminar el archivo temporal después de usarlo
                    if os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                    return Response({"error": "La cara no es real o es una fotografía tomada de una pantalla"}, status=status.HTTP_200_OK)

            except Exception as e:
                if os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                return Response({"error": f"Error en validación de anti-spoofing: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Generar el embedding para la imagen recibida
            try:
                result = DeepFace.represent(img_path=temp_file_path, model_name="Facenet", enforce_detection=True)
                new_embedding = np.array(result[0]['embedding'])  # Extraer el embedding
            except Exception as e:
                if os.path.exists(temp_file_path):
                       os.remove(temp_file_path)
                return Response({"error": f"Error al generar el embedding: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

         

            # Buscar el registro del embedding del usuario en la base de datos
            try:
                record = EmbeddingRecord.objects.get(email=user_email)
                saved_embedding = np.array(record.embedding)  # Convertir el embedding guardado a un array de NumPy
            except EmbeddingRecord.DoesNotExist:
                return Response({"error": "El usuario no tiene un embedding registrado"}, status=status.HTTP_200_OK)

            # Calcular la distancia euclidiana entre los embeddings
            distance = np.linalg.norm(saved_embedding - new_embedding)

            # Umbral para determinar si es la misma persona
            threshold = 10.0  # Ajusta este valor según el modelo usado (Facenet en este caso)

            if distance < threshold:
                # Guardar registro de asistencia
                AttendanceRecord.objects.create(
                    email=user_email,
                    class_name=class_name
                )
                if os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                return Response({"email": user_email, "distance": distance}, status=status.HTTP_200_OK)
            else:
                if os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                return Response({"error": "No se reconoce al usuario", "distance": distance}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": f"Error inesperado: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=False, methods=['get'], authentication_classes=[JWTAuthentication], permission_classes=[IsAdminUser])
    def historial(self, request):
        # Retrieve attendance records from the database
        attendance_records = AttendanceRecord.objects.all()
        serializer = AttendanceRecordSerializer(attendance_records, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
